public class Punct {
	int x, y;
	
	public Punct() {
		x = 0;
		y = 0;
	}
	
	public Punct(int x, int y) {
		this.x = x;
		this.y = y;
	}
}
