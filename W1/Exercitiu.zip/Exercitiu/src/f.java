
public class f {
	public static void Main(String args[]) {
		
	}
}
