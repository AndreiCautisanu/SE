
public class Cerc extends Elipsa {
	public Cerc(int raza, Punct centru) {
		raza1 = raza;
		raza2 = raza;
		this.centru = centru;
	}
}
